# Inbox — messagerie Personnel + Business

Application Flutter (Android) avec serveur Supabase.
Aucune limite d'envoi n'est codée : on peut envoyer autant de messages (même identiques) qu'on veut,
y compris via les listes de diffusion. La seule protection : le destinataire peut **bloquer** l'expéditeur.

## Fonctions
- Connexion par numéro de téléphone + code SMS
- Discussions 1-à-1 et groupes, photos, double coche (verte = lu), non-lus, temps réel
- Compte **Business** (interrupteur dans Profil) : profil entreprise, messages d'accueil/absence automatiques,
  réponses rapides (bouton éclair dans le chat), étiquettes clients, catalogue produits
- Listes de diffusion (texte + photo) envoyées dans la discussion privée de chaque contact
- Blocage d'un contact

Pas encore dans cette V1 : notes vocales, appels, statuts/stories, notifications push quand l'app est fermée.

## Installation (≈ 20 min)

### 1. Créer le serveur Supabase (gratuit)
1. Crée un compte sur https://supabase.com puis un nouveau projet.
2. Menu **SQL Editor** → colle tout le contenu de `supabase/schema.sql` → **Run** (une seule fois).
3. **Project Settings → API** : note l'**URL** et la clé **anon public**.

### 2. Activer les SMS
**Authentication → Providers → Phone** : active-le et choisis un fournisseur SMS (Twilio, Vonage, MessageBird…).
Pour tester sans payer de SMS : dans le même écran, ajoute des **numéros de test** avec un code fixe
(ex. `2250700000001=123456`), et utilise-les pour connecter tes testeurs.

### 3. Obtenir l'APK (sans installer Flutter)
1. Crée un dépôt GitHub privé et envoie-y tout ce dossier.
2. Dépôt → **Settings → Secrets and variables → Actions** : ajoute `SUPABASE_URL` et `SUPABASE_ANON_KEY`.
3. Onglet **Actions → Construire l'APK Inbox → Run workflow**. Au bout de ~5 min, télécharge l'artefact `inbox-apk`.
4. Envoie `app-release.apk` aux testeurs et installe-le (autoriser les sources inconnues).

### Ou en local (si Flutter est installé)
```
flutter create --platforms=android --org ci.inbox --project-name inbox .
# ajoute <uses-permission android:name="android.permission.INTERNET"/> dans android/app/src/main/AndroidManifest.xml
flutter pub get
dart run flutter_launcher_icons
flutter run --dart-define=SUPABASE_URL=https://xxx.supabase.co --dart-define=SUPABASE_ANON_KEY=xxx
```

## Bon à savoir
- Pour la mise en ligne publique (Play Store), prévois : politique de confidentialité, signalement/blocage (le blocage existe),
  notifications push (Firebase Cloud Messaging) et chiffrement de bout en bout si tu veux l'équivalent de WhatsApp.
- Les photos sont dans un stockage public à adresses non devinables : suffisant pour un test, à durcir ensuite.
