/// Renseigne ces deux valeurs (Supabase > Project Settings > API),
/// ou passe-les au build avec --dart-define (voir README).
class Config {
  static const supabaseUrl = String.fromEnvironment('SUPABASE_URL',
      defaultValue: 'https://VOTRE-PROJET.supabase.co');
  static const supabaseAnonKey =
      String.fromEnvironment('SUPABASE_ANON_KEY', defaultValue: 'VOTRE_CLE_ANON');
}
