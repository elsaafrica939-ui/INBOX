import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import 'api.dart';
import 'chat_screen.dart';
import 'theme.dart';
import 'widgets.dart';

class ChatsTab extends StatefulWidget {
  const ChatsTab({super.key});
  @override
  State<ChatsTab> createState() => _ChatsTabState();
}

class _ChatsTabState extends State<ChatsTab> {
  List<Json> _convs = [];
  bool _loading = true;
  String? _error;
  RealtimeChannel? _ch;

  @override
  void initState() {
    super.initState();
    _load();
    _ch = Api.sb
        .channel('inbox-list')
        .onPostgresChanges(
            event: PostgresChangeEvent.all,
            schema: 'public',
            table: 'messages',
            callback: (_) => _load())
        .subscribe();
  }

  @override
  void dispose() {
    if (_ch != null) Api.sb.removeChannel(_ch!);
    super.dispose();
  }

  Future<void> _load() async {
    try {
      final r = await Api.conversations();
      if (mounted) {
        setState(() {
          _convs = r;
          _loading = false;
          _error = null;
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _loading = false;
          _error = '$e';
        });
      }
    }
  }

  Future<void> _open(Json c) async {
    await Navigator.push(
        context,
        MaterialPageRoute(
            builder: (_) => ChatScreen(
                  convId: c['conv_id'] as String,
                  title: c['title'] as String,
                  isGroup: c['is_group'] as bool,
                  otherId: c['other_id'] as String?,
                  otherIsBusiness: c['other_type'] == 'business',
                  avatarUrl: c['avatar_url'] as String?,
                )));
    _load();
  }

  Future<void> _newChat() async {
    final u = await pickUserByPhone(context);
    if (u == null || !mounted) return;
    try {
      final cid = await Api.directChat(u['id'] as String);
      if (!mounted) return;
      await Navigator.push(
          context,
          MaterialPageRoute(
              builder: (_) => ChatScreen(
                    convId: cid,
                    title: u['display_name'] as String,
                    isGroup: false,
                    otherId: u['id'] as String,
                    otherIsBusiness: u['account_type'] == 'business',
                    avatarUrl: u['avatar_url'] as String?,
                  )));
      _load();
    } catch (e) {
      if (mounted) snack(context, 'Erreur : $e');
    }
  }

  Future<void> _newGroup() async {
    final title = await askText(context, 'Nom du groupe');
    if (title == null || title.isEmpty || !mounted) return;
    final members = <Json>[];
    await showDialog(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setD) => AlertDialog(
          title: Text('Membres de « $title »'),
          content: SizedBox(
            width: double.maxFinite,
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              Wrap(spacing: 6, children: [
                for (final m in members)
                  Chip(
                    label: Text(m['display_name'] as String),
                    onDeleted: () => setD(() => members.remove(m)),
                  ),
              ]),
              TextButton.icon(
                icon: const Icon(Icons.person_add),
                label: const Text('Ajouter par numéro'),
                onPressed: () async {
                  final u = await pickUserByPhone(ctx);
                  if (u != null && !members.any((e) => e['id'] == u['id'])) {
                    setD(() => members.add(u));
                  }
                },
              ),
            ]),
          ),
          actions: [
            TextButton(
                onPressed: () => Navigator.pop(ctx),
                child: const Text('Fermer')),
          ],
        ),
      ),
    );
    if (members.isEmpty || !mounted) return;
    try {
      final cid = await Api.createGroup(
          title, members.map((e) => e['id'] as String).toList());
      if (!mounted) return;
      await Navigator.push(
          context,
          MaterialPageRoute(
              builder: (_) =>
                  ChatScreen(convId: cid, title: title, isGroup: true)));
      _load();
    } catch (e) {
      if (mounted) snack(context, 'Erreur : $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Inbox')),
      floatingActionButton: FloatingActionButton(
        child: const Icon(Icons.add_comment),
        onPressed: () => showModalBottomSheet(
          context: context,
          builder: (ctx) => SafeArea(
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              ListTile(
                  leading: const Icon(Icons.person_add),
                  title: const Text('Nouvelle discussion'),
                  onTap: () {
                    Navigator.pop(ctx);
                    _newChat();
                  }),
              ListTile(
                  leading: const Icon(Icons.group_add),
                  title: const Text('Nouveau groupe'),
                  onTap: () {
                    Navigator.pop(ctx);
                    _newGroup();
                  }),
            ]),
          ),
        ),
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _error != null
              ? Center(child: Padding(padding: const EdgeInsets.all(20), child: Text(_error!)))
              : _convs.isEmpty
                  ? const Center(
                      child: Padding(
                      padding: EdgeInsets.all(30),
                      child: Text(
                          "Aucune discussion.\nAppuie sur le bouton vert pour écrire à quelqu'un via son numéro.",
                          textAlign: TextAlign.center),
                    ))
                  : RefreshIndicator(
                      onRefresh: _load,
                      child: ListView.separated(
                        itemCount: _convs.length,
                        separatorBuilder: (_, __) =>
                            const Divider(height: 1, indent: 72),
                        itemBuilder: (_, i) {
                          final c = _convs[i];
                          final unread = (c['unread'] as num?)?.toInt() ?? 0;
                          final isImg = c['last_media'] == 'image';
                          final last = isImg
                              ? '📷 Photo'
                              : ((c['last_body'] as String?) ?? '');
                          return ListTile(
                            leading: Avatar(
                                name: c['title'] as String,
                                url: c['avatar_url'] as String?,
                                business: c['other_type'] == 'business'),
                            title: Text(c['title'] as String,
                                maxLines: 1, overflow: TextOverflow.ellipsis),
                            subtitle: Text(last,
                                maxLines: 1, overflow: TextOverflow.ellipsis),
                            trailing: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                crossAxisAlignment: CrossAxisAlignment.end,
                                children: [
                                  Text(
                                      listTime(DateTime.parse(
                                          c['last_at'] as String)),
                                      style: TextStyle(
                                          fontSize: 12,
                                          color: unread > 0
                                              ? ciGreen
                                              : Colors.black54)),
                                  if (unread > 0)
                                    Container(
                                      margin: const EdgeInsets.only(top: 4),
                                      padding: const EdgeInsets.symmetric(
                                          horizontal: 7, vertical: 2),
                                      decoration: BoxDecoration(
                                          color: ciGreen,
                                          borderRadius:
                                              BorderRadius.circular(12)),
                                      child: Text('$unread',
                                          style: const TextStyle(
                                              color: Colors.white,
                                              fontSize: 12)),
                                    ),
                                ]),
                            onTap: () => _open(c),
                          );
                        },
                      ),
                    ),
    );
  }
}
