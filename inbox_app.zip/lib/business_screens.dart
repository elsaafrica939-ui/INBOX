import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

import 'api.dart';
import 'theme.dart';
import 'widgets.dart';

/// Onglet Business : accès à tous les outils pour les entreprises.
class BusinessTab extends StatelessWidget {
  const BusinessTab({super.key});

  void _go(BuildContext c, Widget w) =>
      Navigator.push(c, MaterialPageRoute(builder: (_) => w));

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Outils Business')),
      body: ListView(children: [
        ListTile(
            leading: const Icon(Icons.store, color: ciGreen),
            title: const Text("Profil de l'entreprise"),
            subtitle: const Text('Nom, adresse, horaires, site web'),
            onTap: () => _go(context, const BusinessProfileScreen())),
        ListTile(
            leading: const Icon(Icons.auto_awesome, color: ciGreen),
            title: const Text('Messages automatiques'),
            subtitle: const Text("Accueil et absence"),
            onTap: () => _go(context, const AutoMessagesScreen())),
        ListTile(
            leading: const Icon(Icons.bolt, color: ciGreen),
            title: const Text('Réponses rapides'),
            subtitle: const Text("Messages prêts à envoyer en un clic"),
            onTap: () => _go(context, const QuickRepliesScreen())),
        ListTile(
            leading: const Icon(Icons.label, color: ciGreen),
            title: const Text('Étiquettes'),
            subtitle: const Text('Organise tes clients (Nouveau, Payé, VIP…)'),
            onTap: () => _go(context, const LabelsScreen())),
        ListTile(
            leading: const Icon(Icons.shopping_bag, color: ciGreen),
            title: const Text('Catalogue'),
            subtitle: const Text('Tes produits et services'),
            onTap: () => _go(
                context, CatalogScreen(ownerId: Api.uid, editable: true))),
      ]),
    );
  }
}

class BusinessProfileScreen extends StatefulWidget {
  const BusinessProfileScreen({super.key});
  @override
  State<BusinessProfileScreen> createState() => _BusinessProfileScreenState();
}

class _BusinessProfileScreenState extends State<BusinessProfileScreen> {
  final _f = {
    'business_name': TextEditingController(),
    'category': TextEditingController(),
    'description': TextEditingController(),
    'address': TextEditingController(),
    'hours': TextEditingController(),
    'website': TextEditingController(),
  };
  bool _loaded = false;

  @override
  void initState() {
    super.initState();
    Api.businessProfile(Api.uid).then((p) {
      if (p != null) {
        _f.forEach((k, c) => c.text = (p[k] ?? '') as String);
      }
      if (mounted) setState(() => _loaded = true);
    });
  }

  Future<void> _save() async {
    try {
      await Api.saveBusinessProfile({for (final e in _f.entries) e.key: e.value.text.trim()});
      if (mounted) {
        snack(context, 'Enregistré.');
        Navigator.pop(context);
      }
    } catch (e) {
      if (mounted) snack(context, 'Erreur : $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    const labels = {
      'business_name': "Nom de l'entreprise",
      'category': 'Catégorie (ex : Vêtements, Restaurant)',
      'description': 'Description',
      'address': 'Adresse',
      'hours': 'Horaires (ex : Lun-Sam 8h-19h)',
      'website': 'Site web',
    };
    return Scaffold(
      appBar: AppBar(title: const Text("Profil de l'entreprise")),
      body: !_loaded
          ? const Center(child: CircularProgressIndicator())
          : ListView(padding: const EdgeInsets.all(16), children: [
              for (final e in _f.entries)
                Padding(
                  padding: const EdgeInsets.only(bottom: 12),
                  child: TextField(
                    controller: e.value,
                    maxLines: e.key == 'description' ? 3 : 1,
                    decoration: InputDecoration(labelText: labels[e.key]),
                  ),
                ),
              FilledButton(
                  style: FilledButton.styleFrom(backgroundColor: ciGreen),
                  onPressed: _save,
                  child: const Text('Enregistrer')),
            ]),
    );
  }
}

class AutoMessagesScreen extends StatefulWidget {
  const AutoMessagesScreen({super.key});
  @override
  State<AutoMessagesScreen> createState() => _AutoMessagesScreenState();
}

class _AutoMessagesScreenState extends State<AutoMessagesScreen> {
  final _greeting = TextEditingController();
  final _away = TextEditingController();
  bool _gOn = false, _aOn = false, _loaded = false;

  @override
  void initState() {
    super.initState();
    Api.businessProfile(Api.uid).then((p) {
      if (p != null) {
        _greeting.text = (p['greeting'] ?? '') as String;
        _away.text = (p['away_message'] ?? '') as String;
        _gOn = p['greeting_enabled'] == true;
        _aOn = p['away_enabled'] == true;
      }
      if (mounted) setState(() => _loaded = true);
    });
  }

  Future<void> _save() async {
    try {
      await Api.saveBusinessProfile({
        'greeting': _greeting.text.trim(),
        'greeting_enabled': _gOn,
        'away_message': _away.text.trim(),
        'away_enabled': _aOn,
      });
      if (mounted) {
        snack(context, 'Enregistré.');
        Navigator.pop(context);
      }
    } catch (e) {
      if (mounted) snack(context, 'Erreur : $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Messages automatiques')),
      body: !_loaded
          ? const Center(child: CircularProgressIndicator())
          : ListView(padding: const EdgeInsets.all(16), children: [
              SwitchListTile(
                  title: const Text("Message d'accueil"),
                  subtitle: const Text("Envoyé au premier message d'un client"),
                  value: _gOn,
                  onChanged: (v) => setState(() => _gOn = v)),
              TextField(
                  controller: _greeting,
                  maxLines: 3,
                  decoration: const InputDecoration(
                      hintText: 'Bonjour ! Merci de nous contacter…')),
              const SizedBox(height: 20),
              SwitchListTile(
                  title: const Text("Message d'absence"),
                  subtitle: const Text('Envoyé au plus une fois toutes les 12 h par client'),
                  value: _aOn,
                  onChanged: (v) => setState(() => _aOn = v)),
              TextField(
                  controller: _away,
                  maxLines: 3,
                  decoration: const InputDecoration(
                      hintText: 'Nous sommes absents, réponse demain matin.')),
              const SizedBox(height: 20),
              FilledButton(
                  style: FilledButton.styleFrom(backgroundColor: ciGreen),
                  onPressed: _save,
                  child: const Text('Enregistrer')),
            ]),
    );
  }
}

class QuickRepliesScreen extends StatefulWidget {
  const QuickRepliesScreen({super.key});
  @override
  State<QuickRepliesScreen> createState() => _QuickRepliesScreenState();
}

class _QuickRepliesScreenState extends State<QuickRepliesScreen> {
  List<Json> _items = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final r = await Api.quickReplies();
    if (mounted) setState(() => _items = r);
  }

  Future<void> _add() async {
    final sc = await askText(context, 'Raccourci (ex : prix)');
    if (sc == null || sc.isEmpty || !mounted) return;
    final tx = await askText(context, 'Message', lines: 5);
    if (tx == null || tx.isEmpty) return;
    try {
      await Api.addQuickReply(sc.replaceAll('/', ''), tx);
      _load();
    } catch (e) {
      if (mounted) snack(context, 'Erreur : $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Réponses rapides')),
      floatingActionButton:
          FloatingActionButton(onPressed: _add, child: const Icon(Icons.add)),
      body: _items.isEmpty
          ? const Center(child: Text('Aucune réponse rapide.'))
          : ListView(children: [
              for (final q in _items)
                ListTile(
                  title: Text('/${q['shortcut']}'),
                  subtitle: Text(q['text'] as String),
                  trailing: IconButton(
                      icon: const Icon(Icons.delete_outline),
                      onPressed: () async {
                        await Api.deleteQuickReply(q['id'] as String);
                        _load();
                      }),
                ),
            ]),
    );
  }
}

class LabelsScreen extends StatefulWidget {
  const LabelsScreen({super.key});
  @override
  State<LabelsScreen> createState() => _LabelsScreenState();
}

class _LabelsScreenState extends State<LabelsScreen> {
  List<Json> _items = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final r = await Api.labels();
    if (mounted) setState(() => _items = r);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Étiquettes')),
      floatingActionButton: FloatingActionButton(
          child: const Icon(Icons.add),
          onPressed: () async {
            final n = await askText(context, "Nom de l'étiquette");
            if (n == null || n.isEmpty) return;
            await Api.addLabel(n);
            _load();
          }),
      body: _items.isEmpty
          ? const Center(
              child: Padding(
                  padding: EdgeInsets.all(24),
                  child: Text(
                      "Aucune étiquette.\nUne fois créées, tu les attribues depuis le menu ⋮ d'une discussion.",
                      textAlign: TextAlign.center)))
          : ListView(children: [
              for (final l in _items)
                ListTile(
                  leading: const Icon(Icons.label, color: ciGreen),
                  title: Text(l['name'] as String),
                  trailing: IconButton(
                      icon: const Icon(Icons.delete_outline),
                      onPressed: () async {
                        await Api.deleteLabel(l['id'] as String);
                        _load();
                      }),
                ),
            ]),
    );
  }
}

class CatalogScreen extends StatefulWidget {
  final String ownerId;
  final bool editable;
  const CatalogScreen({super.key, required this.ownerId, required this.editable});
  @override
  State<CatalogScreen> createState() => _CatalogScreenState();
}

class _CatalogScreenState extends State<CatalogScreen> {
  List<Json> _items = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final r = await Api.products(widget.ownerId);
    if (mounted) {
      setState(() {
        _items = r;
        _loading = false;
      });
    }
  }

  Future<void> _add() async {
    final name = await askText(context, 'Nom du produit');
    if (name == null || name.isEmpty || !mounted) return;
    final price = await askText(context, 'Prix (FCFA)');
    if (price == null || !mounted) return;
    final desc = await askText(context, 'Description (facultatif)', lines: 3);
    if (!mounted) return;
    String? url;
    try {
      final f = await ImagePicker().pickImage(source: ImageSource.gallery, imageQuality: 75);
      if (f != null) url = await Api.uploadImage(f);
      await Api.addProduct(
          name: name,
          description: desc ?? '',
          price: num.tryParse(price.replaceAll(' ', '')) ?? 0,
          imageUrl: url);
      _load();
    } catch (e) {
      if (mounted) snack(context, 'Erreur : $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Catalogue')),
      floatingActionButton: widget.editable
          ? FloatingActionButton(onPressed: _add, child: const Icon(Icons.add))
          : null,
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _items.isEmpty
              ? const Center(child: Text('Catalogue vide.'))
              : ListView(children: [
                  for (final p in _items)
                    ListTile(
                      leading: p['image_url'] != null
                          ? ClipRRect(
                              borderRadius: BorderRadius.circular(8),
                              child: Image.network(p['image_url'] as String,
                                  width: 52,
                                  height: 52,
                                  fit: BoxFit.cover,
                                  errorBuilder: (_, __, ___) =>
                                      const Icon(Icons.image_not_supported)))
                          : const Icon(Icons.shopping_bag, color: ciOrange),
                      title: Text(p['name'] as String),
                      subtitle: Text(
                          '${(p['price'] as num).toStringAsFixed(0)} ${p['currency']}'
                          '${(p['description'] as String).isNotEmpty ? '\n${p['description']}' : ''}'),
                      isThreeLine: (p['description'] as String).isNotEmpty,
                      trailing: widget.editable
                          ? IconButton(
                              icon: const Icon(Icons.delete_outline),
                              onPressed: () async {
                                await Api.deleteProduct(p['id'] as String);
                                _load();
                              })
                          : null,
                    ),
                ]),
    );
  }
}
