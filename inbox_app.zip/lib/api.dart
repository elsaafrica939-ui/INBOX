import 'package:image_picker/image_picker.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

typedef Json = Map<String, dynamic>;

/// Toutes les communications avec Supabase passent par ici.
/// Aucune limite d'envoi n'est appliquée côté application.
class Api {
  static SupabaseClient get sb => Supabase.instance.client;
  static String get uid => sb.auth.currentUser!.id;

  static List<Json> _list(dynamic r) => (r as List)
      .map((e) => Map<String, dynamic>.from(e as Map))
      .toList();

  // ---------- Profil ----------
  static Future<Json?> myProfile() async =>
      await sb.from('profiles').select().eq('id', uid).maybeSingle();

  static Future<void> saveProfile(
      {required String name, required String type, String? businessName}) async {
    await sb
        .from('profiles')
        .update({'display_name': name, 'account_type': type}).eq('id', uid);
    if (type == 'business') {
      await sb.from('business_profiles').upsert({
        'user_id': uid,
        if (businessName != null && businessName.isNotEmpty)
          'business_name': businessName,
      }, onConflict: 'user_id');
    }
  }

  static Future<void> setAbout(String about) async =>
      await sb.from('profiles').update({'about': about}).eq('id', uid);

  // ---------- Contacts & discussions ----------
  static Future<List<Json>> findByPhone(String phone) async =>
      _list(await sb.rpc('find_user_by_phone', params: {'p': phone}));

  static Future<String> directChat(String otherId) async =>
      (await sb.rpc('get_or_create_direct', params: {'other': otherId}))
          as String;

  static Future<String> createGroup(String title, List<String> members) async =>
      (await sb.rpc('create_group',
          params: {'p_title': title, 'p_members': members})) as String;

  static Future<List<Json>> conversations() async =>
      _list(await sb.rpc('my_conversations'));

  static Stream<List<Json>> messagesStream(String convId) => sb
      .from('messages')
      .stream(primaryKey: ['id'])
      .eq('conversation_id', convId)
      .order('created_at', ascending: true);

  static Stream<List<Json>> membersStream(String convId) => sb
      .from('conversation_members')
      .stream(primaryKey: ['conversation_id', 'user_id']).eq(
          'conversation_id', convId);

  static Future<Map<String, String>> memberNames(String convId) async {
    final m = _list(await sb
        .from('conversation_members')
        .select('user_id')
        .eq('conversation_id', convId));
    final ids = m.map((e) => e['user_id'] as String).toList();
    if (ids.isEmpty) return {};
    final p = _list(
        await sb.from('profiles').select('id,display_name').inFilter('id', ids));
    return {for (final e in p) e['id'] as String: e['display_name'] as String};
  }

  static Future<void> markRead(String convId) async => await sb
      .from('conversation_members')
      .update({'last_read_at': DateTime.now().toUtc().toIso8601String()})
      .eq('conversation_id', convId)
      .eq('user_id', uid);

  static Future<void> sendMessage(String convId,
      {String body = '', String? mediaUrl}) async {
    await sb.from('messages').insert({
      'conversation_id': convId,
      'sender_id': uid,
      'body': body,
      'media_url': mediaUrl,
      'media_type': mediaUrl == null ? 'text' : 'image',
    });
  }

  static Future<String> uploadImage(XFile f) async {
    final bytes = await f.readAsBytes();
    final path = '$uid/${DateTime.now().microsecondsSinceEpoch}.jpg';
    await sb.storage.from('media').uploadBinary(path, bytes,
        fileOptions: const FileOptions(contentType: 'image/jpeg'));
    return sb.storage.from('media').getPublicUrl(path);
  }

  // ---------- Blocage ----------
  static Future<bool> isBlocked(String otherId) async =>
      (await sb
              .from('blocks')
              .select()
              .eq('blocker_id', uid)
              .eq('blocked_id', otherId)
              .maybeSingle()) !=
      null;

  static Future<void> setBlocked(String otherId, bool blocked) async {
    if (blocked) {
      await sb
          .from('blocks')
          .upsert({'blocker_id': uid, 'blocked_id': otherId});
    } else {
      await sb
          .from('blocks')
          .delete()
          .eq('blocker_id', uid)
          .eq('blocked_id', otherId);
    }
  }

  // ---------- Listes de diffusion ----------
  static Future<List<Json>> broadcastLists() async => _list(await sb
      .from('broadcast_lists')
      .select('id,name,broadcast_members(count)')
      .order('created_at'));

  static Future<String> createBroadcast(String name) async {
    final r = await sb
        .from('broadcast_lists')
        .insert({'owner_id': uid, 'name': name})
        .select('id')
        .single();
    return r['id'] as String;
  }

  static Future<void> deleteBroadcast(String id) async =>
      await sb.from('broadcast_lists').delete().eq('id', id);

  static Future<List<Json>> broadcastMembers(String listId) async {
    final m = _list(await sb
        .from('broadcast_members')
        .select('user_id')
        .eq('list_id', listId));
    final ids = m.map((e) => e['user_id'] as String).toList();
    if (ids.isEmpty) return [];
    return _list(await sb
        .from('profiles')
        .select('id,display_name,phone')
        .inFilter('id', ids));
  }

  static Future<void> addBroadcastMember(String listId, String userId) async =>
      await sb
          .from('broadcast_members')
          .upsert({'list_id': listId, 'user_id': userId});

  static Future<void> removeBroadcastMember(String listId, String userId) async =>
      await sb
          .from('broadcast_members')
          .delete()
          .eq('list_id', listId)
          .eq('user_id', userId);

  /// Envoie le même message à chaque membre, dans sa discussion privée.
  /// Retourne le nombre de messages réellement envoyés.
  static Future<int> sendBroadcast(String listId,
      {String text = '',
      XFile? image,
      void Function(int done, int total)? onProgress}) async {
    final members = _list(await sb
        .from('broadcast_members')
        .select('user_id')
        .eq('list_id', listId));
    String? url;
    if (image != null) url = await uploadImage(image);
    var done = 0, ok = 0;
    for (final m in members) {
      try {
        final cid = await directChat(m['user_id'] as String);
        await sendMessage(cid, body: text, mediaUrl: url);
        ok++;
      } catch (_) {}
      done++;
      onProgress?.call(done, members.length);
    }
    return ok;
  }

  // ---------- Business ----------
  static Future<Json?> businessProfile(String userId) async => await sb
      .from('business_profiles')
      .select()
      .eq('user_id', userId)
      .maybeSingle();

  static Future<void> saveBusinessProfile(Json data) async =>
      await sb.from('business_profiles').upsert({...data, 'user_id': uid},
          onConflict: 'user_id');

  static Future<List<Json>> quickReplies() async => _list(await sb
      .from('quick_replies')
      .select()
      .eq('owner_id', uid)
      .order('shortcut'));

  static Future<void> addQuickReply(String shortcut, String text) async =>
      await sb
          .from('quick_replies')
          .insert({'owner_id': uid, 'shortcut': shortcut, 'text': text});

  static Future<void> deleteQuickReply(String id) async =>
      await sb.from('quick_replies').delete().eq('id', id);

  static Future<List<Json>> labels() async =>
      _list(await sb.from('labels').select().eq('owner_id', uid).order('name'));

  static Future<void> addLabel(String name) async =>
      await sb.from('labels').insert({'owner_id': uid, 'name': name});

  static Future<void> deleteLabel(String id) async =>
      await sb.from('labels').delete().eq('id', id);

  static Future<Set<String>> contactLabelIds(String contactId) async {
    final r = _list(await sb
        .from('contact_labels')
        .select('label_id')
        .eq('owner_id', uid)
        .eq('contact_id', contactId));
    return r.map((e) => e['label_id'] as String).toSet();
  }

  static Future<void> toggleContactLabel(
      String contactId, String labelId, bool on) async {
    if (on) {
      await sb.from('contact_labels').upsert(
          {'owner_id': uid, 'contact_id': contactId, 'label_id': labelId});
    } else {
      await sb
          .from('contact_labels')
          .delete()
          .eq('owner_id', uid)
          .eq('contact_id', contactId)
          .eq('label_id', labelId);
    }
  }

  static Future<List<Json>> products(String ownerId) async => _list(await sb
      .from('products')
      .select()
      .eq('owner_id', ownerId)
      .order('created_at'));

  static Future<void> addProduct(
          {required String name,
          required String description,
          required num price,
          String? imageUrl}) async =>
      await sb.from('products').insert({
        'owner_id': uid,
        'name': name,
        'description': description,
        'price': price,
        'image_url': imageUrl,
      });

  static Future<void> deleteProduct(String id) async =>
      await sb.from('products').delete().eq('id', id);
}
