import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

import 'api.dart';
import 'theme.dart';
import 'widgets.dart';

/// Listes de diffusion : le même message envoyé à plusieurs contacts,
/// chacun le reçoit dans sa discussion privée. Aucune limite de répétition.
class BroadcastTab extends StatefulWidget {
  const BroadcastTab({super.key});
  @override
  State<BroadcastTab> createState() => _BroadcastTabState();
}

class _BroadcastTabState extends State<BroadcastTab> {
  List<Json> _lists = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final r = await Api.broadcastLists();
      if (mounted) {
        setState(() {
          _lists = r;
          _loading = false;
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() => _loading = false);
        snack(context, 'Erreur : $e');
      }
    }
  }

  int _count(Json l) {
    final m = l['broadcast_members'];
    if (m is List && m.isNotEmpty) return (m.first['count'] as num).toInt();
    return 0;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Listes de diffusion')),
      floatingActionButton: FloatingActionButton(
        child: const Icon(Icons.add),
        onPressed: () async {
          final n = await askText(context, 'Nom de la liste');
          if (n == null || n.isEmpty) return;
          try {
            await Api.createBroadcast(n);
            _load();
          } catch (e) {
            if (context.mounted) snack(context, 'Erreur : $e');
          }
        },
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _lists.isEmpty
              ? const Center(
                  child: Padding(
                      padding: EdgeInsets.all(24),
                      child: Text(
                          "Crée une liste, ajoute des contacts, puis envoie-leur le même message en une fois.",
                          textAlign: TextAlign.center)))
              : ListView(children: [
                  for (final l in _lists)
                    ListTile(
                      leading: const CircleAvatar(
                          backgroundColor: ciGreen,
                          child: Icon(Icons.campaign, color: Colors.white)),
                      title: Text(l['name'] as String),
                      subtitle: Text('${_count(l)} contact(s)'),
                      onTap: () async {
                        await Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (_) => BroadcastDetailScreen(
                                    listId: l['id'] as String,
                                    name: l['name'] as String)));
                        _load();
                      },
                    ),
                ]),
    );
  }
}

class BroadcastDetailScreen extends StatefulWidget {
  final String listId;
  final String name;
  const BroadcastDetailScreen({super.key, required this.listId, required this.name});
  @override
  State<BroadcastDetailScreen> createState() => _BroadcastDetailScreenState();
}

class _BroadcastDetailScreenState extends State<BroadcastDetailScreen> {
  final _ctl = TextEditingController();
  List<Json> _members = [];
  XFile? _image;
  bool _sending = false;
  String _progress = '';

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final m = await Api.broadcastMembers(widget.listId);
    if (mounted) setState(() => _members = m);
  }

  Future<void> _addMember() async {
    final u = await pickUserByPhone(context);
    if (u == null) return;
    try {
      await Api.addBroadcastMember(widget.listId, u['id'] as String);
      _load();
    } catch (e) {
      if (mounted) snack(context, 'Erreur : $e');
    }
  }

  Future<void> _send() async {
    final text = _ctl.text.trim();
    if (text.isEmpty && _image == null) return;
    if (_members.isEmpty) {
      snack(context, 'Ajoute au moins un contact.');
      return;
    }
    setState(() {
      _sending = true;
      _progress = '0/${_members.length}';
    });
    try {
      final ok = await Api.sendBroadcast(widget.listId,
          text: text,
          image: _image,
          onProgress: (d, t) {
            if (mounted) setState(() => _progress = '$d/$t');
          });
      if (mounted) {
        snack(context, '$ok message(s) envoyé(s) sur ${_members.length}.');
        _ctl.clear();
        setState(() => _image = null);
      }
    } catch (e) {
      if (mounted) snack(context, 'Erreur : $e');
    } finally {
      if (mounted) setState(() => _sending = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.name), actions: [
        IconButton(
            icon: const Icon(Icons.delete_outline),
            onPressed: () async {
              await Api.deleteBroadcast(widget.listId);
              if (context.mounted) Navigator.pop(context);
            }),
      ]),
      body: Column(children: [
        Expanded(
          child: ListView(children: [
            ListTile(
                leading: const Icon(Icons.person_add, color: ciGreen),
                title: const Text('Ajouter un contact'),
                onTap: _addMember),
            for (final m in _members)
              ListTile(
                leading: Avatar(name: (m['display_name'] ?? '') as String),
                title: Text((m['display_name'] ?? '') as String),
                subtitle: Text('+${m['phone'] ?? ''}'),
                trailing: IconButton(
                    icon: const Icon(Icons.close),
                    onPressed: () async {
                      await Api.removeBroadcastMember(
                          widget.listId, m['id'] as String);
                      _load();
                    }),
              ),
          ]),
        ),
        if (_image != null)
          ListTile(
            leading: const Icon(Icons.photo),
            title: Text(_image!.name, maxLines: 1, overflow: TextOverflow.ellipsis),
            trailing: IconButton(
                icon: const Icon(Icons.close),
                onPressed: () => setState(() => _image = null)),
          ),
        SafeArea(
          top: false,
          child: Padding(
            padding: const EdgeInsets.fromLTRB(6, 4, 6, 6),
            child: Row(children: [
              IconButton(
                  icon: const Icon(Icons.photo),
                  onPressed: () async {
                    final f = await ImagePicker()
                        .pickImage(source: ImageSource.gallery, imageQuality: 75);
                    if (f != null) setState(() => _image = f);
                  }),
              Expanded(
                child: TextField(
                  controller: _ctl,
                  minLines: 1,
                  maxLines: 5,
                  decoration: InputDecoration(
                    hintText: 'Message pour toute la liste',
                    filled: true,
                    fillColor: const Color(0xFFF1F1F1),
                    contentPadding:
                        const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                    border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(24),
                        borderSide: BorderSide.none),
                  ),
                ),
              ),
              const SizedBox(width: 6),
              CircleAvatar(
                backgroundColor: ciGreen,
                child: _sending
                    ? Text(_progress,
                        style: const TextStyle(color: Colors.white, fontSize: 11))
                    : IconButton(
                        icon: const Icon(Icons.send, color: Colors.white, size: 20),
                        onPressed: _send),
              ),
            ]),
          ),
        ),
      ]),
    );
  }
}
