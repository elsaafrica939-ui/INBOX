import 'package:flutter/material.dart';

import 'api.dart';
import 'broadcast_screens.dart';
import 'business_screens.dart';
import 'chats_tab.dart';
import 'widgets.dart';

class HomeScreen extends StatefulWidget {
  final Json profile;
  const HomeScreen({super.key, required this.profile});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _i = 0;
  late Json _profile = widget.profile;

  bool get _isBusiness => _profile['account_type'] == 'business';

  Future<void> _reloadProfile() async {
    final p = await Api.myProfile();
    if (p != null && mounted) setState(() => _profile = p);
  }

  @override
  Widget build(BuildContext context) {
    final tabs = <Widget>[
      const ChatsTab(),
      const BroadcastTab(),
      if (_isBusiness) const BusinessTab(),
      ProfileTab(profile: _profile, onChanged: _reloadProfile),
    ];
    final dests = <NavigationDestination>[
      const NavigationDestination(
          icon: Icon(Icons.chat_bubble_outline),
          selectedIcon: Icon(Icons.chat_bubble),
          label: 'Discussions'),
      const NavigationDestination(
          icon: Icon(Icons.campaign_outlined),
          selectedIcon: Icon(Icons.campaign),
          label: 'Diffusion'),
      if (_isBusiness)
        const NavigationDestination(
            icon: Icon(Icons.storefront_outlined),
            selectedIcon: Icon(Icons.storefront),
            label: 'Business'),
      const NavigationDestination(
          icon: Icon(Icons.person_outline),
          selectedIcon: Icon(Icons.person),
          label: 'Profil'),
    ];
    if (_i >= tabs.length) _i = 0;
    return Scaffold(
      body: IndexedStack(index: _i, children: tabs),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _i,
        onDestinationSelected: (v) => setState(() => _i = v),
        destinations: dests,
      ),
    );
  }
}

class ProfileTab extends StatelessWidget {
  final Json profile;
  final Future<void> Function() onChanged;
  const ProfileTab({super.key, required this.profile, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    final isBiz = profile['account_type'] == 'business';
    final name = (profile['display_name'] ?? '') as String;
    return Scaffold(
      appBar: AppBar(title: const Text('Profil')),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        Center(child: Avatar(name: name, r: 44, business: isBiz)),
        const SizedBox(height: 12),
        Center(
            child: Text(name,
                style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold))),
        Center(child: Text('+${profile['phone'] ?? ''}')),
        const SizedBox(height: 20),
        ListTile(
          leading: const Icon(Icons.info_outline),
          title: const Text('Infos'),
          subtitle: Text((profile['about'] as String?)?.isNotEmpty == true
              ? profile['about']
              : 'Disponible sur Inbox'),
          onTap: () async {
            final t = await askText(context, 'Mes infos',
                initial: (profile['about'] ?? '') as String);
            if (t == null) return;
            await Api.setAbout(t);
            await onChanged();
          },
        ),
        SwitchListTile(
          secondary: const Icon(Icons.storefront),
          title: const Text('Compte Business'),
          subtitle: const Text('Active les outils pour les entreprises'),
          value: isBiz,
          onChanged: (v) async {
            try {
              await Api.saveProfile(name: name, type: v ? 'business' : 'personal');
              await onChanged();
            } catch (e) {
              if (context.mounted) snack(context, 'Erreur : $e');
            }
          },
        ),
        const Divider(),
        ListTile(
          leading: const Icon(Icons.logout, color: Colors.red),
          title: const Text('Se déconnecter'),
          onTap: () => Api.sb.auth.signOut(),
        ),
      ]),
    );
  }
}
