import 'package:flutter/material.dart';

import 'api.dart';
import 'theme.dart';
import 'widgets.dart';

class OnboardingScreen extends StatefulWidget {
  final VoidCallback onDone;
  const OnboardingScreen({super.key, required this.onDone});
  @override
  State<OnboardingScreen> createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends State<OnboardingScreen> {
  final _name = TextEditingController();
  final _biz = TextEditingController();
  String _type = 'personal';
  bool _busy = false;

  Future<void> _save() async {
    if (_name.text.trim().isEmpty) {
      snack(context, 'Entre ton nom.');
      return;
    }
    setState(() => _busy = true);
    try {
      await Api.saveProfile(
          name: _name.text.trim(),
          type: _type,
          businessName: _biz.text.trim().isEmpty ? _name.text.trim() : _biz.text.trim());
      widget.onDone();
    } catch (e) {
      if (mounted) snack(context, 'Erreur : $e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Bienvenue sur Inbox')),
      body: ListView(padding: const EdgeInsets.all(20), children: [
        TextField(
            controller: _name,
            decoration: const InputDecoration(
                labelText: 'Ton nom', prefixIcon: Icon(Icons.person))),
        const SizedBox(height: 20),
        const Text('Type de compte', style: TextStyle(fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        SegmentedButton<String>(
          segments: const [
            ButtonSegment(
                value: 'personal', label: Text('Personnel'), icon: Icon(Icons.person)),
            ButtonSegment(
                value: 'business', label: Text('Business'), icon: Icon(Icons.storefront)),
          ],
          selected: {_type},
          onSelectionChanged: (s) => setState(() => _type = s.first),
        ),
        if (_type == 'business') ...[
          const SizedBox(height: 16),
          TextField(
              controller: _biz,
              decoration: const InputDecoration(
                  labelText: "Nom de l'entreprise",
                  prefixIcon: Icon(Icons.storefront))),
          const SizedBox(height: 8),
          const Text(
              'Le compte Business donne : profil entreprise, réponses rapides, étiquettes, catalogue, messages automatiques et listes de diffusion.',
              style: TextStyle(color: Colors.black54)),
        ],
        const SizedBox(height: 24),
        FilledButton(
            style: FilledButton.styleFrom(backgroundColor: ciGreen),
            onPressed: _busy ? null : _save,
            child: Text(_busy ? '...' : 'Commencer')),
      ]),
    );
  }
}
