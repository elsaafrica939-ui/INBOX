import 'dart:async';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

import 'api.dart';
import 'business_screens.dart';
import 'theme.dart';
import 'widgets.dart';

class ChatScreen extends StatefulWidget {
  final String convId;
  final String title;
  final bool isGroup;
  final String? otherId;
  final bool otherIsBusiness;
  final String? avatarUrl;
  const ChatScreen({
    super.key,
    required this.convId,
    required this.title,
    required this.isGroup,
    this.otherId,
    this.otherIsBusiness = false,
    this.avatarUrl,
  });
  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final _ctl = TextEditingController();
  late final Stream<List<Json>> _msgs = Api.messagesStream(widget.convId);
  StreamSubscription<List<Json>>? _memSub;
  Map<String, String> _names = {};
  DateTime? _otherRead;
  String? _lastMarked;
  bool _iAmBusiness = false;
  bool _blocked = false;

  @override
  void initState() {
    super.initState();
    Api.memberNames(widget.convId).then((n) {
      if (mounted) setState(() => _names = n);
    });
    Api.myProfile().then((p) {
      if (mounted && p != null) {
        setState(() => _iAmBusiness = p['account_type'] == 'business');
      }
    });
    if (widget.otherId != null) {
      Api.isBlocked(widget.otherId!).then((b) {
        if (mounted) setState(() => _blocked = b);
      });
    }
    _memSub = Api.membersStream(widget.convId).listen((rows) {
      DateTime? min;
      for (final r in rows) {
        if (r['user_id'] == Api.uid) continue;
        final d = DateTime.parse(r['last_read_at'] as String);
        if (min == null || d.isBefore(min)) min = d;
      }
      if (mounted) setState(() => _otherRead = min);
    });
  }

  @override
  void dispose() {
    _memSub?.cancel();
    _ctl.dispose();
    super.dispose();
  }

  Future<void> _sendText() async {
    final t = _ctl.text.trim();
    if (t.isEmpty) return;
    _ctl.clear();
    try {
      await Api.sendMessage(widget.convId, body: t);
    } catch (e) {
      _ctl.text = t;
      if (mounted) {
        snack(context, 'Message non envoyé (bloqué ou hors ligne) : $e');
      }
    }
  }

  Future<void> _sendImage(ImageSource src) async {
    try {
      final f = await ImagePicker().pickImage(source: src, imageQuality: 75);
      if (f == null) return;
      final url = await Api.uploadImage(f);
      await Api.sendMessage(widget.convId, mediaUrl: url);
    } catch (e) {
      if (mounted) snack(context, 'Photo non envoyée : $e');
    }
  }

  void _attach() {
    showModalBottomSheet(
      context: context,
      builder: (ctx) => SafeArea(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          ListTile(
              leading: const Icon(Icons.photo),
              title: const Text('Galerie'),
              onTap: () {
                Navigator.pop(ctx);
                _sendImage(ImageSource.gallery);
              }),
          ListTile(
              leading: const Icon(Icons.photo_camera),
              title: const Text('Appareil photo'),
              onTap: () {
                Navigator.pop(ctx);
                _sendImage(ImageSource.camera);
              }),
        ]),
      ),
    );
  }

  Future<void> _quickReplies() async {
    final list = await Api.quickReplies();
    if (!mounted) return;
    if (list.isEmpty) {
      snack(context, 'Aucune réponse rapide. Crée-en dans l\'onglet Business.');
      return;
    }
    showModalBottomSheet(
      context: context,
      builder: (ctx) => SafeArea(
        child: ListView(shrinkWrap: true, children: [
          for (final q in list)
            ListTile(
              leading: const Icon(Icons.bolt, color: ciOrange),
              title: Text('/${q['shortcut']}'),
              subtitle:
                  Text(q['text'] as String, maxLines: 2, overflow: TextOverflow.ellipsis),
              onTap: () {
                _ctl.text = q['text'] as String;
                Navigator.pop(ctx);
              },
            ),
        ]),
      ),
    );
  }

  Future<void> _labelSheet() async {
    final labels = await Api.labels();
    final active = await Api.contactLabelIds(widget.otherId!);
    if (!mounted) return;
    if (labels.isEmpty) {
      snack(context, "Aucune étiquette. Crée-en dans l'onglet Business.");
      return;
    }
    showModalBottomSheet(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setS) => SafeArea(
          child: ListView(shrinkWrap: true, children: [
            for (final l in labels)
              CheckboxListTile(
                title: Text(l['name'] as String),
                value: active.contains(l['id']),
                onChanged: (v) async {
                  await Api.toggleContactLabel(
                      widget.otherId!, l['id'] as String, v == true);
                  setS(() {
                    v == true ? active.add(l['id'] as String) : active.remove(l['id']);
                  });
                },
              ),
          ]),
        ),
      ),
    );
  }

  Future<void> _toggleBlock() async {
    final nv = !_blocked;
    try {
      await Api.setBlocked(widget.otherId!, nv);
      if (mounted) {
        setState(() => _blocked = nv);
        snack(context, nv ? 'Contact bloqué.' : 'Contact débloqué.');
      }
    } catch (e) {
      if (mounted) snack(context, 'Erreur : $e');
    }
  }

  Widget _tick(DateTime created) {
    final read = _otherRead != null && !_otherRead!.isBefore(created);
    return Icon(Icons.done_all,
        size: 16, color: read ? ciGreen : Colors.black38);
  }

  Widget _bubble(Json m) {
    final mine = m['sender_id'] == Api.uid;
    final created = DateTime.parse(m['created_at'] as String);
    final isImg = m['media_type'] == 'image' && m['media_url'] != null;
    final body = (m['body'] ?? '') as String;
    final auto = m['is_auto'] == true;
    return Align(
      alignment: mine ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        constraints:
            BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.78),
        margin: const EdgeInsets.symmetric(vertical: 3, horizontal: 8),
        padding: const EdgeInsets.fromLTRB(10, 6, 10, 4),
        decoration: BoxDecoration(
          color: mine ? bubbleMine : const Color(0xFFF1F1F1),
          borderRadius: BorderRadius.circular(12),
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          if (widget.isGroup && !mine)
            Text(_names[m['sender_id']] ?? '',
                style: const TextStyle(
                    color: ciGreen, fontWeight: FontWeight.bold, fontSize: 12)),
          if (auto)
            const Text('Message automatique',
                style: TextStyle(fontSize: 10, color: Colors.black45)),
          if (isImg)
            Padding(
              padding: const EdgeInsets.only(bottom: 4),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(8),
                child: Image.network(m['media_url'] as String,
                    fit: BoxFit.cover,
                    errorBuilder: (_, __, ___) =>
                        const Icon(Icons.broken_image, size: 48)),
              ),
            ),
          if (body.isNotEmpty) Text(body, style: const TextStyle(fontSize: 16)),
          Align(
            alignment: Alignment.bottomRight,
            child: Row(mainAxisSize: MainAxisSize.min, children: [
              Text(hhmm(created),
                  style: const TextStyle(fontSize: 11, color: Colors.black45)),
              if (mine) ...[const SizedBox(width: 3), _tick(created)],
            ]),
          ),
        ]),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        titleSpacing: 0,
        title: Row(children: [
          Avatar(
              name: widget.title,
              url: widget.avatarUrl,
              r: 18,
              business: widget.otherIsBusiness),
          const SizedBox(width: 10),
          Expanded(
              child: Text(widget.title,
                  maxLines: 1, overflow: TextOverflow.ellipsis)),
        ]),
        actions: [
          if (!widget.isGroup && widget.otherId != null)
            PopupMenuButton<String>(
              onSelected: (v) {
                if (v == 'labels') _labelSheet();
                if (v == 'catalog') {
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (_) => CatalogScreen(
                              ownerId: widget.otherId!, editable: false)));
                }
                if (v == 'block') _toggleBlock();
              },
              itemBuilder: (_) => [
                if (_iAmBusiness)
                  const PopupMenuItem(value: 'labels', child: Text('Étiquettes')),
                if (widget.otherIsBusiness)
                  const PopupMenuItem(
                      value: 'catalog', child: Text('Voir le catalogue')),
                PopupMenuItem(
                    value: 'block',
                    child: Text(_blocked ? 'Débloquer' : 'Bloquer')),
              ],
            ),
        ],
      ),
      body: Column(children: [
        Expanded(
          child: StreamBuilder<List<Json>>(
            stream: _msgs,
            builder: (context, snap) {
              if (snap.hasError) {
                return Center(child: Text('Erreur : ${snap.error}'));
              }
              if (!snap.hasData) {
                return const Center(child: CircularProgressIndicator());
              }
              final list = snap.data!;
              if (list.isNotEmpty) {
                final last = list.last;
                if (last['sender_id'] != Api.uid && last['id'] != _lastMarked) {
                  _lastMarked = last['id'] as String;
                  WidgetsBinding.instance.addPostFrameCallback(
                      (_) => Api.markRead(widget.convId).catchError((_) {}));
                }
              }
              if (list.isEmpty) {
                return const Center(child: Text('Dis bonjour 👋'));
              }
              final rev = list.reversed.toList();
              return ListView.builder(
                reverse: true,
                padding: const EdgeInsets.symmetric(vertical: 8),
                itemCount: rev.length,
                itemBuilder: (_, i) => _bubble(rev[i]),
              );
            },
          ),
        ),
        SafeArea(
          top: false,
          child: Padding(
            padding: const EdgeInsets.fromLTRB(6, 4, 6, 6),
            child: Row(children: [
              IconButton(
                  icon: const Icon(Icons.attach_file), onPressed: _attach),
              if (_iAmBusiness)
                IconButton(
                    icon: const Icon(Icons.bolt, color: ciOrange),
                    tooltip: 'Réponses rapides',
                    onPressed: _quickReplies),
              Expanded(
                child: TextField(
                  controller: _ctl,
                  minLines: 1,
                  maxLines: 5,
                  textCapitalization: TextCapitalization.sentences,
                  decoration: InputDecoration(
                    hintText: 'Message',
                    filled: true,
                    fillColor: const Color(0xFFF1F1F1),
                    contentPadding:
                        const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                    border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(24),
                        borderSide: BorderSide.none),
                  ),
                ),
              ),
              const SizedBox(width: 6),
              CircleAvatar(
                backgroundColor: ciGreen,
                child: IconButton(
                    icon: const Icon(Icons.send, color: Colors.white, size: 20),
                    onPressed: _sendText),
              ),
            ]),
          ),
        ),
      ]),
    );
  }
}
