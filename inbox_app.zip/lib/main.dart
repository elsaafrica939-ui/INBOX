import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import 'api.dart';
import 'auth_screen.dart';
import 'config.dart';
import 'home_screen.dart';
import 'onboarding_screen.dart';
import 'theme.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Supabase.initialize(
      url: Config.supabaseUrl, anonKey: Config.supabaseAnonKey);
  runApp(const InboxApp());
}

class InboxApp extends StatelessWidget {
  const InboxApp({super.key});

  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'Inbox',
        debugShowCheckedModeBanner: false,
        theme: inboxTheme,
        home: const AuthGate(),
      );
}

class AuthGate extends StatelessWidget {
  const AuthGate({super.key});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<AuthState>(
      stream: Supabase.instance.client.auth.onAuthStateChange,
      builder: (context, _) {
        final session = Supabase.instance.client.auth.currentSession;
        if (session == null) return const AuthScreen();
        return ProfileGate(key: ValueKey(session.user.id));
      },
    );
  }
}

/// Après connexion : si le profil n'a pas encore de nom, on demande l'inscription.
class ProfileGate extends StatefulWidget {
  const ProfileGate({super.key});
  @override
  State<ProfileGate> createState() => _ProfileGateState();
}

class _ProfileGateState extends State<ProfileGate> {
  late Future<Json?> _f = Api.myProfile();

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<Json?>(
      future: _f,
      builder: (context, snap) {
        if (snap.connectionState != ConnectionState.done) {
          return const Scaffold(body: Center(child: CircularProgressIndicator()));
        }
        if (snap.hasError) {
          return Scaffold(
              body: Center(
                  child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              Text('Erreur de chargement : ${snap.error}'),
              const SizedBox(height: 12),
              FilledButton(
                  onPressed: () => setState(() => _f = Api.myProfile()),
                  child: const Text('Réessayer')),
            ]),
          )));
        }
        final p = snap.data;
        if (p == null || (p['display_name'] as String).isEmpty) {
          return OnboardingScreen(
              onDone: () => setState(() => _f = Api.myProfile()));
        }
        return HomeScreen(profile: p);
      },
    );
  }
}
