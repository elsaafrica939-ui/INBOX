import 'package:flutter/material.dart';
import 'api.dart';
import 'theme.dart';

void snack(BuildContext c, String m) =>
    ScaffoldMessenger.of(c).showSnackBar(SnackBar(content: Text(m)));

String hhmm(DateTime d) {
  final l = d.toLocal();
  return '${l.hour.toString().padLeft(2, '0')}:${l.minute.toString().padLeft(2, '0')}';
}

String listTime(DateTime d) {
  final l = d.toLocal();
  final n = DateTime.now();
  if (l.year == n.year && l.month == n.month && l.day == n.day) return hhmm(l);
  return '${l.day.toString().padLeft(2, '0')}/${l.month.toString().padLeft(2, '0')}';
}

class Avatar extends StatelessWidget {
  final String name;
  final String? url;
  final double r;
  final bool business;
  const Avatar(
      {super.key, required this.name, this.url, this.r = 22, this.business = false});

  @override
  Widget build(BuildContext context) {
    final has = url != null && url!.isNotEmpty;
    final initial = name.trim().isEmpty ? '?' : name.trim()[0].toUpperCase();
    return Stack(clipBehavior: Clip.none, children: [
      CircleAvatar(
        radius: r,
        backgroundColor: ciOrange,
        backgroundImage: has ? NetworkImage(url!) : null,
        child: has
            ? null
            : Text(initial,
                style: const TextStyle(
                    color: Colors.white, fontWeight: FontWeight.bold)),
      ),
      if (business)
        Positioned(
          right: -2,
          bottom: -2,
          child: Container(
            padding: const EdgeInsets.all(2),
            decoration:
                const BoxDecoration(color: Colors.white, shape: BoxShape.circle),
            child: const Icon(Icons.storefront, size: 13, color: ciGreen),
          ),
        ),
    ]);
  }
}

/// Demande un numéro et retourne l'utilisateur Inbox correspondant (ou null).
Future<Json?> pickUserByPhone(BuildContext context) async {
  final c = TextEditingController(text: '+225');
  final phone = await showDialog<String>(
    context: context,
    builder: (ctx) => AlertDialog(
      title: const Text('Numéro du contact'),
      content: TextField(
        controller: c,
        keyboardType: TextInputType.phone,
        autofocus: true,
        decoration: const InputDecoration(hintText: '+225 07 00 00 00 00'),
      ),
      actions: [
        TextButton(
            onPressed: () => Navigator.pop(ctx), child: const Text('Annuler')),
        FilledButton(
            onPressed: () => Navigator.pop(ctx, c.text.trim()),
            child: const Text('Chercher')),
      ],
    ),
  );
  if (phone == null || phone.length < 6) return null;
  try {
    final r = await Api.findByPhone(phone);
    if (r.isEmpty) {
      if (context.mounted) {
        snack(context, "Aucun utilisateur Inbox avec ce numéro.");
      }
      return null;
    }
    return r.first;
  } catch (e) {
    if (context.mounted) snack(context, 'Erreur : $e');
    return null;
  }
}

Future<String?> askText(BuildContext context, String title,
    {String hint = '', String initial = '', int lines = 1}) async {
  final c = TextEditingController(text: initial);
  return showDialog<String>(
    context: context,
    builder: (ctx) => AlertDialog(
      title: Text(title),
      content: TextField(
          controller: c,
          autofocus: true,
          minLines: 1,
          maxLines: lines,
          decoration: InputDecoration(hintText: hint)),
      actions: [
        TextButton(
            onPressed: () => Navigator.pop(ctx), child: const Text('Annuler')),
        FilledButton(
            onPressed: () => Navigator.pop(ctx, c.text.trim()),
            child: const Text('OK')),
      ],
    ),
  );
}
