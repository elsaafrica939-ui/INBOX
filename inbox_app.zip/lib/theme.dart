import 'package:flutter/material.dart';

const ciOrange = Color(0xFFFF8200);
const ciGreen = Color(0xFF009E60);
const bubbleMine = Color(0xFFFFE7CC);

final inboxTheme = ThemeData(
  useMaterial3: true,
  colorScheme: ColorScheme.fromSeed(
      seedColor: ciOrange, primary: ciOrange, secondary: ciGreen),
  scaffoldBackgroundColor: Colors.white,
  appBarTheme: const AppBarTheme(
      backgroundColor: ciOrange, foregroundColor: Colors.white, elevation: 0),
  floatingActionButtonTheme: const FloatingActionButtonThemeData(
      backgroundColor: ciGreen, foregroundColor: Colors.white),
  navigationBarTheme: const NavigationBarThemeData(
      indicatorColor: Color(0xFFFFE0BF), backgroundColor: Colors.white),
);
