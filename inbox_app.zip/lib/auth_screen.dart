import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import 'api.dart';
import 'theme.dart';
import 'widgets.dart';

class AuthScreen extends StatefulWidget {
  const AuthScreen({super.key});
  @override
  State<AuthScreen> createState() => _AuthScreenState();
}

class _AuthScreenState extends State<AuthScreen> {
  final _phone = TextEditingController(text: '+225');
  final _code = TextEditingController();
  bool _sent = false;
  bool _busy = false;

  Future<void> _send() async {
    setState(() => _busy = true);
    try {
      await Api.sb.auth.signInWithOtp(phone: _phone.text.trim());
      if (mounted) setState(() => _sent = true);
    } on AuthException catch (e) {
      if (mounted) snack(context, e.message);
    } catch (e) {
      if (mounted) snack(context, 'Erreur : $e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _verify() async {
    setState(() => _busy = true);
    try {
      await Api.sb.auth.verifyOTP(
          phone: _phone.text.trim(),
          token: _code.text.trim(),
          type: OtpType.sms);
    } on AuthException catch (e) {
      if (mounted) snack(context, e.message);
    } catch (e) {
      if (mounted) snack(context, 'Erreur : $e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: ciOrange,
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              Image.asset('assets/icon-512x512.png', width: 110),
              const SizedBox(height: 12),
              const Text('INBOX',
                  style: TextStyle(
                      color: Colors.white,
                      fontSize: 32,
                      fontWeight: FontWeight.w800,
                      letterSpacing: 6)),
              const SizedBox(height: 4),
              const Text('Discutez sans limites',
                  style: TextStyle(color: Colors.white)),
              const SizedBox(height: 28),
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(18),
                  child: Column(children: [
                    TextField(
                      controller: _phone,
                      enabled: !_sent,
                      keyboardType: TextInputType.phone,
                      decoration: const InputDecoration(
                          labelText: 'Numéro de téléphone',
                          prefixIcon: Icon(Icons.phone)),
                    ),
                    if (_sent) ...[
                      const SizedBox(height: 12),
                      TextField(
                        controller: _code,
                        keyboardType: TextInputType.number,
                        decoration: const InputDecoration(
                            labelText: 'Code reçu par SMS',
                            prefixIcon: Icon(Icons.sms)),
                      ),
                    ],
                    const SizedBox(height: 16),
                    SizedBox(
                      width: double.infinity,
                      child: FilledButton(
                        style: FilledButton.styleFrom(backgroundColor: ciGreen),
                        onPressed: _busy ? null : (_sent ? _verify : _send),
                        child: Text(_busy
                            ? '...'
                            : (_sent ? 'Valider le code' : 'Recevoir le code')),
                      ),
                    ),
                    if (_sent)
                      TextButton(
                          onPressed: () => setState(() => _sent = false),
                          child: const Text('Changer de numéro')),
                  ]),
                ),
              ),
            ]),
          ),
        ),
      ),
    );
  }
}
