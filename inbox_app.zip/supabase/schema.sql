-- =====================================================================
-- INBOX : schéma Supabase (à coller dans Supabase > SQL Editor > Run)
-- Aucune limite sur le nombre de messages ni sur les messages identiques.
-- Seule protection : un utilisateur peut BLOQUER un expéditeur.
-- =====================================================================

-- ---------- Profils ----------
create table if not exists profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  phone text,
  display_name text not null default '',
  avatar_url text,
  about text not null default '',
  account_type text not null default 'personal' check (account_type in ('personal','business')),
  created_at timestamptz not null default now()
);
create unique index if not exists profiles_phone_uq on profiles(phone) where phone <> '';

create table if not exists business_profiles (
  user_id uuid primary key references profiles(id) on delete cascade,
  business_name text not null default '',
  category text not null default '',
  description text not null default '',
  address text not null default '',
  hours text not null default '',
  website text not null default '',
  greeting_enabled boolean not null default false,
  greeting text not null default '',
  away_enabled boolean not null default false,
  away_message text not null default ''
);

-- ---------- Discussions ----------
create table if not exists conversations (
  id uuid primary key default gen_random_uuid(),
  is_group boolean not null default false,
  title text,
  avatar_url text,
  created_by uuid references profiles(id),
  created_at timestamptz not null default now()
);

create table if not exists conversation_members (
  conversation_id uuid references conversations(id) on delete cascade,
  user_id uuid references profiles(id) on delete cascade,
  role text not null default 'member',
  last_read_at timestamptz not null default now(),
  primary key (conversation_id, user_id)
);
create index if not exists cm_user_idx on conversation_members(user_id);

create table if not exists messages (
  id uuid primary key default gen_random_uuid(),
  conversation_id uuid not null references conversations(id) on delete cascade,
  sender_id uuid not null references profiles(id),
  body text not null default '',
  media_url text,
  media_type text not null default 'text' check (media_type in ('text','image')),
  is_auto boolean not null default false,
  created_at timestamptz not null default now()
);
create index if not exists messages_conv_idx on messages(conversation_id, created_at);

create table if not exists blocks (
  blocker_id uuid references profiles(id) on delete cascade,
  blocked_id uuid references profiles(id) on delete cascade,
  primary key (blocker_id, blocked_id)
);

-- ---------- Outils Business ----------
create table if not exists quick_replies (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references profiles(id) on delete cascade,
  shortcut text not null,
  text text not null
);

create table if not exists labels (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references profiles(id) on delete cascade,
  name text not null,
  color text not null default '#009E60'
);

create table if not exists contact_labels (
  owner_id uuid references profiles(id) on delete cascade,
  contact_id uuid references profiles(id) on delete cascade,
  label_id uuid references labels(id) on delete cascade,
  primary key (owner_id, contact_id, label_id)
);

create table if not exists products (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references profiles(id) on delete cascade,
  name text not null,
  description text not null default '',
  price numeric not null default 0,
  currency text not null default 'XOF',
  image_url text,
  available boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists broadcast_lists (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references profiles(id) on delete cascade,
  name text not null,
  created_at timestamptz not null default now()
);

create table if not exists broadcast_members (
  list_id uuid references broadcast_lists(id) on delete cascade,
  user_id uuid references profiles(id) on delete cascade,
  primary key (list_id, user_id)
);

-- ---------- Fonctions utilitaires ----------
create or replace function is_member(cid uuid) returns boolean
language sql security definer set search_path = public stable as $$
  select exists (select 1 from conversation_members where conversation_id = cid and user_id = auth.uid());
$$;

-- Création automatique du profil à l'inscription
create or replace function handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into profiles(id, phone) values (new.id, regexp_replace(coalesce(new.phone,''), '\D', '', 'g'))
  on conflict do nothing;
  return new;
end $$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
  for each row execute function handle_new_user();

-- Trouver un utilisateur par numéro
create or replace function find_user_by_phone(p text)
returns table(id uuid, display_name text, avatar_url text, account_type text)
language sql security definer set search_path = public stable as $$
  select pr.id, pr.display_name, pr.avatar_url, pr.account_type
  from profiles pr
  where pr.phone = regexp_replace(p, '\D', '', 'g') and pr.id <> auth.uid() and pr.display_name <> '';
$$;

-- Discussion 1-à-1 (créée si elle n'existe pas)
create or replace function get_or_create_direct(other uuid) returns uuid
language plpgsql security definer set search_path = public as $$
declare cid uuid;
begin
  if other = auth.uid() then raise exception 'impossible'; end if;
  select c.id into cid from conversations c
  where not c.is_group
    and exists (select 1 from conversation_members m where m.conversation_id = c.id and m.user_id = auth.uid())
    and exists (select 1 from conversation_members m where m.conversation_id = c.id and m.user_id = other)
  limit 1;
  if cid is null then
    insert into conversations(is_group, created_by) values (false, auth.uid()) returning id into cid;
    insert into conversation_members(conversation_id, user_id) values (cid, auth.uid()), (cid, other);
  end if;
  return cid;
end $$;

create or replace function create_group(p_title text, p_members uuid[]) returns uuid
language plpgsql security definer set search_path = public as $$
declare cid uuid; m uuid;
begin
  insert into conversations(is_group, title, created_by) values (true, p_title, auth.uid()) returning id into cid;
  insert into conversation_members(conversation_id, user_id, role) values (cid, auth.uid(), 'admin');
  foreach m in array p_members loop
    if m <> auth.uid() then
      insert into conversation_members(conversation_id, user_id) values (cid, m) on conflict do nothing;
    end if;
  end loop;
  return cid;
end $$;

-- Liste des discussions avec dernier message et non-lus
create or replace function my_conversations()
returns table(conv_id uuid, is_group boolean, title text, avatar_url text, other_id uuid,
              other_type text, last_body text, last_media text, last_at timestamptz, unread bigint)
language sql security definer set search_path = public stable as $$
  select c.id, c.is_group,
         coalesce(case when c.is_group then c.title else p.display_name end, 'Inbox'),
         case when c.is_group then c.avatar_url else p.avatar_url end,
         p.id, p.account_type,
         lm.body, lm.media_type, coalesce(lm.created_at, c.created_at),
         (select count(*) from messages m
            where m.conversation_id = c.id and m.sender_id <> auth.uid() and m.created_at > me.last_read_at)
  from conversation_members me
  join conversations c on c.id = me.conversation_id
  left join conversation_members om
         on om.conversation_id = c.id and om.user_id <> auth.uid() and not c.is_group
  left join profiles p on p.id = om.user_id
  left join lateral (
      select m.body, m.media_type, m.created_at from messages m
      where m.conversation_id = c.id order by m.created_at desc limit 1) lm on true
  where me.user_id = auth.uid()
  order by coalesce(lm.created_at, c.created_at) desc;
$$;

-- Message d'accueil / d'absence automatiques (compte Business)
create or replace function handle_auto_replies() returns trigger
language plpgsql security definer set search_path = public as $$
declare bid uuid; bp business_profiles%rowtype; cnt int; isgrp boolean; acc text;
begin
  if new.is_auto then return new; end if;
  select c.is_group into isgrp from conversations c where c.id = new.conversation_id;
  if isgrp then return new; end if;
  select user_id into bid from conversation_members
    where conversation_id = new.conversation_id and user_id <> new.sender_id limit 1;
  if bid is null then return new; end if;
  select account_type into acc from profiles where id = bid;
  if acc is distinct from 'business' then return new; end if;
  select * into bp from business_profiles where user_id = bid;
  if not found then return new; end if;
  select count(*) into cnt from messages
    where conversation_id = new.conversation_id and sender_id = new.sender_id and id <> new.id;
  if cnt = 0 and bp.greeting_enabled and bp.greeting <> '' then
    insert into messages(conversation_id, sender_id, body, is_auto)
      values (new.conversation_id, bid, bp.greeting, true);
  elsif bp.away_enabled and bp.away_message <> ''
        and not exists (select 1 from messages where conversation_id = new.conversation_id
                        and sender_id = bid and is_auto and created_at > now() - interval '12 hours') then
    insert into messages(conversation_id, sender_id, body, is_auto)
      values (new.conversation_id, bid, bp.away_message, true);
  end if;
  return new;
end $$;
drop trigger if exists on_message_auto_reply on messages;
create trigger on_message_auto_reply after insert on messages
  for each row execute function handle_auto_replies();

-- ---------- Sécurité (RLS) ----------
alter table profiles enable row level security;
alter table business_profiles enable row level security;
alter table conversations enable row level security;
alter table conversation_members enable row level security;
alter table messages enable row level security;
alter table blocks enable row level security;
alter table quick_replies enable row level security;
alter table labels enable row level security;
alter table contact_labels enable row level security;
alter table products enable row level security;
alter table broadcast_lists enable row level security;
alter table broadcast_members enable row level security;

create policy "profiles lecture" on profiles for select to authenticated using (true);
create policy "profiles modif" on profiles for update to authenticated using (id = auth.uid());

create policy "business lecture" on business_profiles for select to authenticated using (true);
create policy "business ecriture" on business_profiles for all to authenticated
  using (user_id = auth.uid()) with check (user_id = auth.uid());

create policy "conv lecture" on conversations for select to authenticated using (is_member(id));

create policy "membres lecture" on conversation_members for select to authenticated using (is_member(conversation_id));
create policy "membres lu" on conversation_members for update to authenticated using (user_id = auth.uid());

create policy "messages lecture" on messages for select to authenticated using (is_member(conversation_id));
create policy "messages envoi" on messages for insert to authenticated
  with check (
    sender_id = auth.uid() and is_member(conversation_id)
    and not exists (
      select 1 from blocks b
      join conversation_members m on m.user_id = b.blocker_id
      join conversations c on c.id = m.conversation_id
      where c.id = messages.conversation_id and not c.is_group and b.blocked_id = auth.uid())
  );

create policy "blocks perso" on blocks for all to authenticated
  using (blocker_id = auth.uid()) with check (blocker_id = auth.uid());

create policy "quick perso" on quick_replies for all to authenticated
  using (owner_id = auth.uid()) with check (owner_id = auth.uid());
create policy "labels perso" on labels for all to authenticated
  using (owner_id = auth.uid()) with check (owner_id = auth.uid());
create policy "contact_labels perso" on contact_labels for all to authenticated
  using (owner_id = auth.uid()) with check (owner_id = auth.uid());

create policy "produits lecture" on products for select to authenticated using (true);
create policy "produits ecriture" on products for all to authenticated
  using (owner_id = auth.uid()) with check (owner_id = auth.uid());

create policy "diffusion perso" on broadcast_lists for all to authenticated
  using (owner_id = auth.uid()) with check (owner_id = auth.uid());
create policy "diffusion membres perso" on broadcast_members for all to authenticated
  using (exists (select 1 from broadcast_lists l where l.id = list_id and l.owner_id = auth.uid()))
  with check (exists (select 1 from broadcast_lists l where l.id = list_id and l.owner_id = auth.uid()));

-- ---------- Temps réel ----------
alter publication supabase_realtime add table messages;
alter publication supabase_realtime add table conversation_members;

-- ---------- Stockage des photos ----------
insert into storage.buckets (id, name, public) values ('media', 'media', true)
on conflict (id) do nothing;
create policy "media lecture" on storage.objects for select using (bucket_id = 'media');
create policy "media envoi" on storage.objects for insert to authenticated
  with check (bucket_id = 'media' and (storage.foldername(name))[1] = auth.uid()::text);
